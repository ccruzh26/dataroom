import { useState, useRef } from 'react';
import { Document } from '@/lib/types';
import OutlineTree from './OutlineTree';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, FileText, Plus, FolderPlus, Upload } from 'lucide-react';

interface DocumentPanelProps {
  documents: Document[];
  selectedDocId: string | null;
  onSelectDocument: (doc: Document) => void;
  onCreateDocument?: () => void;
  onCreateFolder?: () => void;
  onUpdateDocument?: (doc: Document) => void;
  onReorderDocuments?: (documents: Document[]) => void;
  onUploadFile?: (file: File) => void;
}

export default function DocumentPanel({ 
  documents, 
  selectedDocId, 
  onSelectDocument,
  onCreateDocument,
  onCreateFolder,
  onUpdateDocument,
  onReorderDocuments,
  onUploadFile,
}: DocumentPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onUploadFile) {
      onUploadFile(file);
    }
    if (e.target) {
      e.target.value = '';
    }
  };
  
  return (
    <div className="flex flex-col h-full bg-sidebar" data-testid="document-panel">
      <div className="shrink-0 p-4 border-b border-sidebar-border space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-muted-foreground" />
            <h2 className="text-base font-semibold">Documents</h2>
          </div>
          <div className="flex items-center gap-1">
            <Button
              data-testid="button-create-folder"
              size="icon"
              variant="ghost"
              onClick={onCreateFolder}
              title="New folder"
            >
              <FolderPlus className="w-4 h-4" />
            </Button>
            <Button
              data-testid="button-create-document"
              size="icon"
              variant="ghost"
              onClick={onCreateDocument}
              title="New document"
            >
              <Plus className="w-4 h-4" />
            </Button>
            <Button
              data-testid="button-upload-file"
              size="icon"
              variant="ghost"
              onClick={handleUploadClick}
              title="Upload file (PDF, CSV, Excel)"
            >
              <Upload className="w-4 h-4" />
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.csv,.xls,.xlsx"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
        </div>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            data-testid="input-search-documents"
            type="search"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-background h-8 text-sm"
          />
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2">
          <OutlineTree
            documents={documents}
            selectedDocId={selectedDocId}
            onSelectDocument={onSelectDocument}
            onUpdateDocument={onUpdateDocument}
            onReorderDocuments={onReorderDocuments}
            searchQuery={searchQuery}
          />
        </div>
      </ScrollArea>
    </div>
  );
}
