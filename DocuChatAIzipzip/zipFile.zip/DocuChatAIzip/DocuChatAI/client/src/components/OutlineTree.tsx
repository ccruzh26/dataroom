import { useState, useRef, useEffect } from 'react';
import { Document } from '@/lib/types';
import { ChevronRight, ChevronDown, Folder, FileText, FileSpreadsheet, File } from 'lucide-react';
import { Input } from '@/components/ui/input';

function getFileIcon(document: Document) {
  if (document.isFile) {
    if (document.fileType === 'pdf') {
      return <File className="w-4 h-4 text-red-500 shrink-0" />;
    } else if (document.fileType === 'csv' || document.fileType === 'excel') {
      return <FileSpreadsheet className="w-4 h-4 text-green-600 shrink-0" />;
    }
    return <File className="w-4 h-4 text-muted-foreground shrink-0" />;
  }
  return <FileText className="w-4 h-4 text-muted-foreground shrink-0" />;
}

interface OutlineTreeProps {
  documents: Document[];
  selectedDocId: string | null;
  onSelectDocument: (doc: Document) => void;
  onUpdateDocument?: (doc: Document) => void;
  onReorderDocuments?: (documents: Document[]) => void;
  searchQuery?: string;
}

interface TreeNodeProps {
  document: Document;
  level: number;
  selectedDocId: string | null;
  onSelectDocument: (doc: Document) => void;
  onUpdateDocument?: (doc: Document) => void;
  onReorderDocuments?: (documents: Document[]) => void;
  parentDocuments?: Document[];
  allDocuments: Document[];
  isFiltered?: boolean;
}

function findDocumentById(docs: Document[], id: string): Document | undefined {
  for (const doc of docs) {
    if (doc.id === id) return doc;
    if (doc.children) {
      const found = findDocumentById(doc.children, id);
      if (found) return found;
    }
  }
  return undefined;
}

function isDescendantOf(docs: Document[], parentId: string, childId: string): boolean {
  const parent = findDocumentById(docs, parentId);
  if (!parent || !parent.children) return false;
  for (const child of parent.children) {
    if (child.id === childId) return true;
    if (isDescendantOf(docs, child.id, childId)) return true;
  }
  return false;
}

function TreeNode({ document, level, selectedDocId, onSelectDocument, onUpdateDocument, onReorderDocuments, parentDocuments = [], allDocuments, isFiltered }: TreeNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(document.title);
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const isFolder = document.isFolder;
  const isSelected = document.id === selectedDocId;
  
  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);
  
  const handleNameDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsEditing(true);
  };
  
  const handleSaveName = () => {
    if (editTitle.trim() && editTitle !== document.title) {
      onUpdateDocument?.({ ...document, title: editTitle.trim() });
    } else {
      setEditTitle(document.title);
    }
    setIsEditing(false);
  };
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSaveName();
    } else if (e.key === 'Escape') {
      setEditTitle(document.title);
      setIsEditing(false);
    }
  };
  
  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation();
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', document.id);
  };
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'move';
    if (isFolder) {
      setIsDragOver(true);
    }
  };
  
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    
    try {
      const draggedId = e.dataTransfer.getData('text/plain');
      
      if (draggedId === document.id) return;
      
      const draggedDoc = findDocumentById(allDocuments, draggedId);
      if (!draggedDoc) return;
      
      // If dropping onto a folder, move the item into the folder
      if (isFolder) {
        // Don't allow dropping a parent folder into its own child (using tree context)
        if (isDescendantOf(allDocuments, draggedId, document.id)) return;
        
        // Create update payload without client-only fields like children
        const { children, ...docWithoutChildren } = draggedDoc;
        const updatedDoc = { 
          ...docWithoutChildren, 
          parentId: document.id,
          order: (document.children?.length || 0)
        };
        onUpdateDocument?.(updatedDoc as Document);
        setIsExpanded(true);
      } else if (parentDocuments.length > 0) {
        // Reorder within the same level
        const draggedIndex = parentDocuments.findIndex(d => d.id === draggedId);
        const targetIndex = parentDocuments.findIndex(d => d.id === document.id);
        
        if (draggedIndex !== -1 && targetIndex !== -1 && draggedIndex !== targetIndex) {
          const updated = parentDocuments.filter(d => d.id !== draggedId);
          const reorderedDoc = { ...draggedDoc };
          
          // After removal, indices shift. Use targetIndex directly to place item at/after target position
          const newOrder = [...updated];
          newOrder.splice(targetIndex, 0, reorderedDoc);
          
          newOrder.forEach((doc, idx) => {
            doc.order = idx;
          });
          
          onReorderDocuments?.(newOrder);
        }
      }
    } catch (error) {
      console.error('Error handling drop:', error);
    }
  };
  
  return (
    <div>
      <div
        data-testid={`tree-item-${document.id}`}
        draggable={!isEditing}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => {
          if (isEditing) return;
          if (isFolder) {
            setIsExpanded(!isExpanded);
          } else {
            onSelectDocument(document);
          }
        }}
        onDoubleClick={handleNameDoubleClick}
        className={`flex items-center gap-2 py-1.5 px-2 rounded-md cursor-pointer hover-elevate transition-colors ${
          isSelected ? 'bg-primary/10 border-l-[3px] border-l-primary -ml-[3px] pl-[11px]' : ''
        } ${isDragOver && isFolder ? 'bg-primary/20 ring-2 ring-primary ring-inset' : ''}`}
        style={{ paddingLeft: isSelected ? undefined : `${level * 16 + 8}px` }}
      >
        {isFolder ? (
          <>
            <span className="text-muted-foreground shrink-0">
              {isExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </span>
            <Folder className="w-4 h-4 text-muted-foreground shrink-0" />
          </>
        ) : (
          <>
            <span className="w-4 shrink-0" />
            {getFileIcon(document)}
          </>
        )}
        
        {isEditing ? (
          <Input
            ref={inputRef}
            value={editTitle}
            onChange={(e) => setEditTitle(e.target.value)}
            onBlur={handleSaveName}
            onKeyDown={handleKeyDown}
            onClick={(e) => e.stopPropagation()}
            className="h-6 px-1 text-sm"
            data-testid="input-folder-name"
          />
        ) : (
          <span className={`text-sm truncate ${isSelected ? 'font-medium' : ''}`}>
            {document.title}
          </span>
        )}
      </div>
      
      {isFolder && isExpanded && document.children && (
        <div>
          {document.children.map((child) => (
            <TreeNode
              key={child.id}
              document={child}
              level={level + 1}
              selectedDocId={selectedDocId}
              onSelectDocument={onSelectDocument}
              onUpdateDocument={onUpdateDocument}
              onReorderDocuments={onReorderDocuments}
              parentDocuments={document.children || []}
              allDocuments={allDocuments}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function OutlineTree({ documents, selectedDocId, onSelectDocument, onUpdateDocument, onReorderDocuments, searchQuery }: OutlineTreeProps) {
  const filteredDocs = documents;

  if (filteredDocs.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <FileText className="w-6 h-6 mx-auto mb-2 opacity-50" />
        <p className="text-xs">No documents found</p>
      </div>
    );
  }

  return (
    <div className="space-y-0.5" data-testid="outline-tree">
      {filteredDocs.map((doc) => (
        <TreeNode
          key={doc.id}
          document={doc}
          level={0}
          selectedDocId={selectedDocId}
          onSelectDocument={onSelectDocument}
          onUpdateDocument={onUpdateDocument}
          onReorderDocuments={onReorderDocuments}
          parentDocuments={filteredDocs}
          allDocuments={documents}
        />
      ))}
    </div>
  );
}
