# DocuChatAI - Document Dataroom with AI Assistant

## Overview
A document management application (dataroom) with an integrated AI chat assistant. Users can create, organize, and manage documents in a folder structure, with AI-powered chat functionality for document-related queries.

## Current State
- Application is running and fully functional
- Database schema deployed with tables for documents, sections, chat messages, and users
- AI Assistant feature available in the top-right corner

## Project Architecture

### Tech Stack
- **Frontend**: React 18 with TypeScript, Vite, TailwindCSS, shadcn/ui components
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL (Neon serverless) with Drizzle ORM
- **AI Integration**: OpenAI API

### Directory Structure
```
DocuChatAI/
├── client/           # React frontend
│   ├── src/
│   │   ├── components/   # UI components (shadcn/ui + custom)
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utilities and types
│   │   └── pages/        # Page components
│   └── public/           # Static assets
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API routes
│   ├── storage.ts    # Database storage layer
│   ├── db.ts         # Database connection
│   └── openai.ts     # OpenAI integration
├── shared/           # Shared code
│   └── schema.ts     # Drizzle database schema
└── package.json
```

### Database Schema
- **users**: User accounts
- **documents**: Document/folder entries with hierarchy support
- **document_sections**: Sections within documents (for embeddings)
- **chat_messages**: AI chat history with citations

## Key Features
- Document creation and editing
- Folder organization with hierarchy
- Search functionality
- AI Assistant for document queries
- Dark/light mode toggle

## Running the Application
The app runs on port 5000 with `npm run dev` command.

## Recent Changes
- December 1, 2025: Added file upload for PDFs, CSVs, and Excel files with built-in viewers
- December 1, 2025: Updated branding to "Data Room" and changed document icon to gray
- December 1, 2025: Added file type icons (red for PDF, green for Excel/CSV)
- December 1, 2025: Added drag-and-drop for reordering and moving documents into folders
- December 1, 2025: Made documents renamable via double-click (same as folders)
- December 1, 2025: Initial setup and database schema deployment
